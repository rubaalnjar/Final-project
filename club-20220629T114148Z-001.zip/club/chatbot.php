<?php
include("conn.php");
$id = $_SESSION['id'];
$sql = "SELECT * FROM chatbot WHERE student_id=$id";
$query = mysqli_query($db, $sql);
$date = date("Y-m-d");
$time = date("H:i:s");
if (isset($_POST['msg_send_btn'])) {
  $content = $_POST['content'];
  $sql1 = "INSERT INTO chatbot(student_id,question_id,`time`,`date`)
 VALUES($id,$content,'$time','$date')";
  $query1 = mysqli_query($db, $sql1);
  header("Refresh:0");
}
?>



<html>

<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta charset='utf-8' />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <style>
    .container {
      max-width: 1170px;
      margin: auto;
    }

    img {
      max-width: 100%;
    }

    .inbox_people {
      background: #f8f8f8 none repeat scroll 0 0;
      float: left;
      overflow: hidden;
      width: 80%;
      border-right: 1px solid #c4c4c4;
      margin-left: 10em;
    }

    .inbox_msg {
      /* border: 1px solid #c4c4c4; */
      clear: both;
      overflow: hidden;
    }

    .top_spac {
      margin: 20px 0 0;
    }


    .recent_heading {
      float: left;
      width: 40%;
    }

    .srch_bar {
      display: inline-block;
      text-align: right;
      width: 60%;
      padding: 0em;
    }

    .headind_srch {
      padding: 10px 29px 10px 20px;
      overflow: hidden;
      border-bottom: 1px solid #c4c4c4;
    }

    .recent_heading h4 {
      color: #05728f;
      font-size: 21px;
      margin: auto;
    }

    .srch_bar input {
      border: 1px solid #cdcdcd;
      border-width: 0 0 1px 0;
      width: 80%;
      padding: 2px 0 4px 6px;
      background: none;
    }

    .srch_bar .input-group-addon button {
      background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
      border: medium none;
      padding: 0;
      color: #707070;
      font-size: 18px;
    }

    .srch_bar .input-group-addon {
      margin: 0 0 0 -27px;
    }

    .chat_ib h5 {
      font-size: 15px;
      color: #464646;
      margin: 0 0 8px 0;
    }

    .chat_ib h5 span {
      font-size: 13px;
      float: right;
    }

    .chat_ib p {
      font-size: 14px;
      color: #989898;
      margin: auto
    }

    .chat_img {
      float: left;
      width: 11%;
    }

    .chat_ib {
      float: left;
      padding: 0 0 0 15px;
      width: 88%;
    }

    .chat_people {
      overflow: hidden;
      clear: both;
    }

    .chat_list {
      border-bottom: 1px solid #c4c4c4;
      margin: 0;
      padding: 18px 16px 10px;
    }

    .inbox_chat {
      height: 550px;
      overflow-y: hidden;
    }

    .active_chat {
      background: #ebebeb;
    }

    .incoming_msg_img {
      display: inline-block;
      width: 6%;
    }

    .received_msg {
      display: inline-block;
      padding: 0 0 0 10px;
      vertical-align: top;
      width: 92%;
    }

    .received_withd_msg p {
      background: #ebebeb none repeat scroll 0 0;
      border-radius: 3px;
      color: #646464;
      font-size: 14px;
      margin: 0;
      padding: 5px 10px 5px 12px;
      width: 100%;
    }

    .time_date {
      color: #747474;
      display: block;
      font-size: 12px;
      margin: 8px 0 0;
    }

    .received_withd_msg {
      width: 57%;
    }

    .mesgs {
      float: left;
      padding: 30px 15px 0 25px;
      width: 99%;

    }

    .sent_msg p {
      background: #05728f none repeat scroll 0 0;
      border-radius: 3px;
      font-size: 14px;
      margin: 0;
      color: #fff;
      padding: 5px 10px 5px 12px;
      width: 77%;
    }

    .outgoing_msg {
      overflow: hidden;
      margin: 26px 0 26px;
    }

    .sent_msg {
      float: right;
      width: 46%;
    }

    .input_msg_write input {
      background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
      border: medium none;
      color: #4c4c4c;
      font-size: 15px;
      min-height: 48px;
      width: 100%;
    }

    .type_msg {
      border-top: 1px solid #c4c4c4;
      position: relative;
    }

    .msg_send_btn {
      background: #05728f none repeat scroll 0 0;
      border: medium none;
      border-radius: 50%;
      color: #fff;
      cursor: pointer;
      font-size: 17px;
      height: 33px;
      position: absolute;
      right: 0;
      top: 11px;
      width: 33px;
    }

    .messaging {
      padding: 10px 0 50px 0;
    }

    .msg_history {
      height: 400px;
      overflow-y: auto;
    }

    body {
      font-family: Arial, Helvetica, sans-serif;
    }

    .navbar {
      width: 100%;
      background-color: #174f96;

      overflow: auto;
    }

    .navbar a {
      float: right;
      padding: 10px;
      color: white;
      text-decoration: none;
      font-size: 17px;
    }


    .active {
      background-color: #4CAF50;
    }

    @media screen and (max-width: 500px) {
      .navbar a {
        float: none;
        display: block;
      }
    }


    .grid-container {
      display: grid;
      grid-template-columns: auto auto auto auto auto;
      background-color: rgb(41, 85, 24);
      padding: 0px;
    }

    .grid-item {
      background-color: rgb(41, 85, 24);
      padding: 2px;
      font-size: 20px;
      text-align: center;
      color: #fff;
    }

    .row {
      margin-left: 0px;
      margin-right: 0px;
    }
  </style>

</head>

<body>
  <?php
  include("header.php");
  ?>
  <div class="fluid_container" style="margin-bottom: 2em;padding-bottom: 1em;">
    <div class="row">
      <div class="col-12">
        <h5 style="text-align: center;background-color: #8e7f6f;color:white">
          Welcome to the auto responder service to help you better please choose the appropriate question number from the list below
        </h5>
      </div>
    </div>
    <form action="chatbot.php" method="post">
      <div class="messaging">
        <div class="inbox_msg">
          <div class="inbox_people">


            <div class="mesgs" style="overflow-y: hidden;">
              <div class="msg_history">
              <div class="outgoing_msg" style="width: 90%;">
                  <div class="incoming_msg_img" style="float:right;">
                    <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil">
                  </div>
         
                  <div class="sent_msg">
                    <p style="width: 90%;word-wrap: break-word;">
                    if you do not find what you are looking for, you can inquire through the support page
                    </p>
                  </div>
                </div>

                <div class="outgoing_msg" style="width: 90%;">
                  <div class="incoming_msg_img" style="float:right;">
                    <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil">
                  </div>
         
                  <div class="sent_msg">
                    <p style="width: 90%;word-wrap: break-word;">
                      <?php
                      $sql0 = "SELECT * FROM question";
                      $query0 = mysqli_query($db, $sql0);
                      foreach ($query0 as $row0) {
                        $id0 = $row0['id'];
                        $question0 = $row0['question'];
                      ?>
                        <?= $id0; ?> - <?= $question0; ?> <br>
                      <?php
                      }
                      ?>
                    </p>
                  </div>
                </div>


                <?php
                foreach ($query as $row) {
                  $question_id = $row['question_id'];
                  $sql2 = "SELECT * FROM question WHERE id=$question_id";
                  $query2 = mysqli_query($db, $sql2);
                  foreach ($query2 as $row2) {
                    $question = $row2['question'];
                    $answer = $row2['answer'];
                  }
                  $date_ = $row['date'];
                  $time_ = $row['time'];
                ?>





                  <div class="incoming_msg">
                    <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                    <div class="received_msg">
                      <div class="received_withd_msg">
                        <p>
                          <?= $question; ?>
                        </p>
                        <span class="time_date"> <?= $time_; ?> | <?= $date_; ?> </span>
                      </div>
                    </div>
                  </div>

                  <div class="outgoing_msg" style="width: 90%;">
                    <div class="incoming_msg_img" style="float:right;">
                      <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil">
                    </div>

                    <div class="sent_msg">
                      <p style="width: 90%;word-wrap: break-word;">
                        <?= $answer; ?>
                      </p>
                      <span class="time_date"> <?= $time_; ?> | <?= $date_; ?> </span>
                    </div>
                  </div>

                <?php
                }
                ?>
              </div>


              <div class="type_msg">
                <div class="input_msg_write">
                  <input id="content" name="content" type="text" class="write_msg" placeholder="Type a message" />
                  <button class="msg_send_btn" id="msg_send_btn" name="msg_send_btn" type="submit"><i class="fa fa-paper-plane-o" aria-hidden="true"></i></button>
                </div>
              </div>
            </div>
          </div>



        </div>
      </div>
    </form>
</body>
<?php
include("footer.php");
?>

</html>