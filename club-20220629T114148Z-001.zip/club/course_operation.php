<?php
session_start();
$id = $_GET['course_id'];
$status = $_GET['status'];
include("conn.php");
if($status==1 || $status==2){
if($status==1){
    $status_="accept";
}    
else
{
    $status_="reject";
}
$sql = "UPDATE course SET status='$status_' where id=$id;"; 
$query = mysqli_query($db, $sql);    
}

if($status==3){
    $sql = "DELETE FROM  course where id=$id"; 
    $query = mysqli_query($db, $sql);    
    }

header("location:courses_reg.php");
?>