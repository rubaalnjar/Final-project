<?php
include("conn.php");
?>
<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <style>
    .card-title {
      text-align: center;
      color: #8e7f6f;
    }

    .card-text {
      text-align: center;
      font-size: 20px;
    }

    * {
      box-sizing: border-box
    }

    body {
      font-family: Verdana, sans-serif;
      margin: 0
    }

    .mySlides {
      display: none
    }

    img {
      vertical-align: middle;
    }




    h5 {
      font-size: 1.0rem !important;

    }

    .he {
      margin-top: 0.5em;
      padding: 2px;
      padding-left: 20px;
      padding-right: 20px;
      font-weight: bold;
      font-size: 20px;
    }


    .a1 {
      text-decoration: none;
      text-align: center;
      justify-content: center;
      margin-left: auto;
      margin-right: auto;
      width: 50%;
      display: block;
    }

    .vertical-menu {
      width: 100%;
      position: absolute;
      right: 0;
    }

    .vertical-menu a {
      background-color: #eee;
      color: black;
      display: block;
      padding: 20px;
      text-decoration: none;
    }

    .vertical-menu a:hover {
      background-color: #ccc;
    }

    .vertical-menu a.active {
      background-color: #d2c6b1;
    }
  </style>
</head>

<body style="background-color:#f5f0ec;background-size: inherit;">
  <?php
  include('header.php');
  ?>


  <div class="row" style="margin-bottom: 5em;padding-bottom: 5em;">



    <div class="card col-8">
      <div class="card-body">
        <h2 class="card-title">
          About Us
        </h2>
        <p class="card-text" style="text-align: justify;">
          Student activities are an important forum for building the students’ personality and discovering and developing their creative talents and leadership skills.
          Therefore, attention and encouragement came to it through the establishment of student clubs that contain these events and encourage innovation and creativity among female students. It is also a center for scientific, cultural, social, sports and artistic radiation.
        </p>
      </div>
    </div>

    <div class="col-4">
      <div class="vertical-menu">
        <a href="home.php">Home</a>
        <a href="about.php"  class="active">About Us</a>
        <a href="message.php">Our Message</a>
        <a href="objectives.php">Objectives</a>
        <a href="vision.php">Vision</a>
      </div>
    </div>

    <!-- <div class="card col-2">

      <div class="card-body">
        <h2 class="card-title">
          Vision
        </h2>
        <p class="card-text">
          Scientific leadership and excellence in building a knowledge society.
        </p>

      </div>


    </div>
    <div class="card col-5">
      <div class="card-body">
        <h2 class="card-title">
          Our Message
        </h2>
        <p class="card-text">
          Providing distinguished student activities and services to graduate highly skilled cadres capable of competing locally and internationally by providing high-quality extracurricular activities, infrastructure and superior equipment according to the best international standards </p>

      </div>
    </div>
    <div class="card col-12">
      <div class="card-body">
        <h2 class="card-title">
          Objectives
        </h2>
        <p class="card-text" style="text-align: left;">
          1- Discovering and supporting the talents of students. <br>
          2- Enhancing loyalty between female students and the university. <br>
          3- Develop a love of teamwork.<br>
          4- Female students’ participation in planning, implementing and following up on student activities.<br>
          5- Develop their individual skills and invest free time.<br>
          6- Innovation, innovation and excellence in student activities programs.

      </div>
    </div> -->


  </div>





  <?php
  include("footer.php");
  ?>


</body>

</html>