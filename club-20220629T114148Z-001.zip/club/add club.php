<?php
include("conn.php");
$id=$_SESSION['id'];

if (isset($_POST['save_btn'])) {
  $name = $_POST['name'];
  $description = $_POST['description'];
  $vision = $_POST['vision'];
  $letter = $_POST['letter'];
  $short_goals = $_POST['short_goals'];
  $long_goals = $_POST['long_goals'];
  $target_group = $_POST['target_group'];
  $topic = $_POST['topic'];
  $place = $_POST['place'];
  $addition = $_POST['addition'];

  $sql = "INSERT INTO club(name,description,vision,letter,short_goals,long_goals,target_group,topic,place,addition,professor_id)
   VALUES('$name','$description','$vision','$letter','$short_goals','$long_goals','$target_group','$topic','$place','$addition',$id)";
  $query = mysqli_query($db, $sql);
}





?>


<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<title>add club</title>
<style>

h4,h5{
  text-transform: capitalize;
  }
  .row {
    margin-left: 0em;
    margin-right: 0em;
  }
</style>

<body style="background-color:#f5f0ec;background-size: inherit;" class="gray-bg">

  <?php
  include('header.php');
  ?>
  <form action="add club.php" method="post" enctype="multipart/form-data">
    <div class="container-fluid justify-content-center w-75 mt-2 p-4" style="border-color: #fff;border-style: solid;border-radius: 35px;background:#fff;margin-bottom: 5em;padding-bottom: 5em;">
      <div class="row justify-content-center mt-2">
        <div class="col-6" style="text-align: center;">
          <h4 style="color: #8e7f6f;font-weight: bold;"> add club </h4>
        </div>
      </div>


      <div class="row justify-content-center mt-2">
      <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        <div class="col-4 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> name </h5>
        </div>
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        
        <div class="col-6" style="text-align: center;">
          <input name="name" class="p-2 w-100" type="text"></input>
        </div>
      </div>

      <div class="row justify-content-center mt-2">
      <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        <div class="col-4 mt-1 " style="text-align: center;">
        <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> description </h5>
        </div>
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
      
        <div class="col-6" style="text-align: center;">
          <textarea name="description" class="p-2 w-100">

          </textarea>
        </div>
      </div>

      <div class="row justify-content-center mt-2">
      <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        <div class="col-4 mt-1 " style="text-align: center;">
        <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> vision </h5>
        </div>
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
       
        <div class="col-6" style="text-align: center;">
          <textarea name="vision" class="p-2 w-100">

          </textarea>
        </div>
      </div>

      <div class="row justify-content-center mt-2">
      <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        <div class="col-4 mt-1 " style="text-align: center;">
        <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> message </h5>
        </div>
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
       
        <div class="col-6" style="text-align: center;">
          <textarea name="letter" class="p-2 w-100">

          </textarea>
        </div>
      </div>

      <div class="row justify-content-center mt-2">
    
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        <div class="col-4 mt-1 " style="text-align: center;">
        <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> short term goals </h5>
        </div>
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
       
        <div class="col-6" style="text-align: center;">
          <textarea name="short_goals" class="p-2 w-100">
          </textarea>
        </div>
      </div>

      
      <div class="row justify-content-center mt-2">
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        <div class="col-4 mt-1 " style="text-align: center;">
        <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> long term goals </h5>
        </div>
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>

        <div class="col-6" style="text-align: center;">
          <textarea name="long_goals" class="p-2 w-100">
          </textarea>
        </div>
      </div>


         
      <div class="row justify-content-center mt-2">

        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        <div class="col-4 mt-1 " style="text-align: center;">
        <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> target group </h5>
        </div>
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        <div class="col-6" style="text-align: center;">
          <textarea name="target_group" class="p-2 w-100">
          </textarea>
        </div>
      </div>
      


    
      

        
      <div class="row justify-content-center mt-2">
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        <div class="col-4 mt-1 " style="text-align: center;">
        <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> axes </h5>
        </div>
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        <div class="col-6" style="text-align: center;">
          <textarea name="topic" class="p-2 w-100">
          </textarea>
        </div>
      </div>
      
              
      <div class="row justify-content-center mt-2">
      <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        <div class="col-4 mt-1 " style="text-align: center;">
        <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> place </h5>
        </div>
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
      
        <div class="col-6" style="text-align: center;">
          <textarea name="place" class="p-2 w-100">
          </textarea>
        </div>
      </div>
      
      <div class="row justify-content-center mt-2">
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
        <div class="col-4 mt-1 " style="text-align: center;">
        <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> additions </h5>
        </div>
        <div class="col-1 mt-1 " style="text-align: center;">
      </div>
      
        <div class="col-6" style="text-align: center;">
          <textarea name="addition" class="p-2 w-100">
          </textarea>
        </div>
      </div>

      <div class="row justify-content-center mt-2">
        <div class="col-6" style="text-align: center;">
          <button style="background-color: #8e7f6f;border-color: #8e7f6f;" name="save_btn" type="submit" class="btn btn-success w-75"> create</button>
        </div>
      </div>
    </div>
  </form>

  </div>
  <?php
include("footer.php");
?>

</body>

</html>