<?php
include("conn.php");
if (isset($_POST['login_btn'])) {
	$email = $_POST['email'];
	$password = $_POST['password'];
	$type = $_POST['type'];
	$_SESSION['type'] = $type;
	if ($type == "admin") {
		$sql = "SELECT * FROM $type where email like '$email' and password like '$password' ";
		$query = mysqli_query($db, $sql);
	}
	if ($type == "student") {
		$sql = "SELECT * FROM $type where univ_id = $email and password like '$password' ";
		$query = mysqli_query($db, $sql);
	}
	if ($type == "professor") {
		$sql = "SELECT * FROM $type where emp_id = $email and password like '$password' ";
		$query = mysqli_query($db, $sql);
	}
	if (mysqli_num_rows($query) != 0) {
		foreach ($query as $row) {
			if ($type == "admin") {
				header("location:students.php");
				$_SESSION['id'] = $row['id'];
			}
			if ($type == "student") {
				$_SESSION['id'] = $row['univ_id'];
				header("location:home.php");
			}
			if ($type == "professor") {
				$_SESSION['id'] = $row['emp_id'];
				header("location:home.php");
			}
		}
	}
	else{
		if ($type == "admin") {
		echo "<script>alert('wrong email or password')</script>";
		}
		if ($type == "student") {
			echo "<script>alert('wrong univ id or password')</script>";
		}
		if ($type == "professor") {
			echo "<script>alert('wrong employee id or password')</script>";
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Login V3</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico" />
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->
</head>

<body>
	<div class="limiter">


		<div class="container-login100" style="padding: 0px;background:#f5f0ec;">
			<div class="wrap-login100" style="background: -webkit-linear-gradient(top, #8e7f6f, #8e7f6f);">
				<form action="login.php" method="post" class="login100-form validate-form">
					<span class="login100-form-logo" style="border-radius: 0px;">
						<img src="images/logo.png" style="height: 100%;width: 100%;">

					</span>

					<span class="login100-form-title p-b-34 p-t-27" style="text-transform: capitalize;">
						login
					</span>



					<div class="wrap-input100"  data-validate="Enter required data">
						<input class="input100" type="text" name="email" placeholder="email/university id/employee id">
						<span class="focus-input100" data-placeholder="&#9993;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input class="input100" type="password" name="password" placeholder="Password">
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>



					<div class="wrap-input100 validate-input" data-validate="Enter type">
						<select class="input100" name="type">
							<option style="background:#8e7f6f">admin</option>
							<option style="background:#8e7f6f">student</option>
							<option style="background:#8e7f6f">professor</option>
						</select>
					</div>



					<div class="container-login100-form-btn">
						<button name="login_btn" type="submit" class="login100-form-btn" style="text-transform: capitalize;background: #d4cdc3 !important;">
							login
						</button>
					</div>


					<div class="container-login100-form-btn">
						<a href="student.php" style="text-decoration: none;color: white;text-transform: capitalize;">student signup </a>
					</div>


					<div class="container-login100-form-btn">
						<a href="professor.php" style="text-decoration: none;color: white;text-transform: capitalize;">professor signup </a>
					</div>


				</form>
			</div>
		</div>
	</div>


	<div id="dropDownSelect1"></div>

	<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
	<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>

</html>