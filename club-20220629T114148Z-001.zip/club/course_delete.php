<?php
session_start();
$id = $_GET['id'];
echo $id;
include("conn.php");
$sql = "DELETE FROM course where id='$id';";
$query = mysqli_query($db, $sql);

if($_SESSION['type']=='admin'){
header("location:courses_admin.php");
}
else{
header("location:courses_teacher.php");
}
?>
