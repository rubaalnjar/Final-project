<?php
// session_start();
include("conn.php");
$id = $_GET['id'];
$accept = $_GET['accept'];
$sql = "UPDATE student SET accept_training='$accept' where univ_id=$id;";
$query = mysqli_query($db, $sql);
header("location:students.php");
?>
