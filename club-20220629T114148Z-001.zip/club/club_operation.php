<?php
session_start();
$student_id = $_GET['student_id'];
$club_id = $_GET['club_id'];
$status = $_GET['status'];
include("conn.php");
if($status==1 || $status==2){
if($status==1){
    $status_="accept";
}    
else
{
    $status_="reject";
}
$sql = "UPDATE student_club SET status='$status_' where (student_id=$student_id AND club_id=$club_id);"; 
$query = mysqli_query($db, $sql);    
}
if($status==3){
    $sql = "DELETE FROM  student_club  where (student_id=$student_id AND club_id=$club_id)"; 
    $query = mysqli_query($db, $sql);    
    }
header("location:clubs_reg.php");
?>