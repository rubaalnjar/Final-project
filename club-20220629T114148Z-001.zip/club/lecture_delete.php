<?php
session_start();
$id = $_GET['id'];
include("conn.php");
$sql = "DELETE FROM lecture where id=$id;";
$query = mysqli_query($db, $sql);
if($_SESSION['type']=='admin'){
header("location:lectures_admin.php");
}
else{
header("location:lectures_teacher.php");
}
?>
