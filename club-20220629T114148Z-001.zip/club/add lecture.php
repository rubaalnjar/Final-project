<?php
include("conn.php");
$id=$_SESSION['id'];
$sql1 = "SELECT * FROM course where club_id IN (SELECT club_id FROM student_club) AND status like 'accept'";
$query1 = mysqli_query($db, $sql1);
if (isset($_POST['save_btn'])) {
  $title = $_POST['title'];
  $description = $_POST['description'];
  $type = $_POST['type'];
  $place = $_POST['place'];
  $date = $_POST['date'];
  $time = $_POST['time'];
  $course = $_POST['course'];
  $sql = "INSERT INTO lecture(title,description,type,link,`date`,`time`,course_id)
VALUES('$title','$description','$type','$place','$date','$time',$course)";
  $query = mysqli_query($db, $sql);
}
?>


<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<title>add lecture</title>
<style>
  
  .row {
    margin-left: 0em;
    margin-right: 0em;
  }

h4,h5{
  text-transform: capitalize;
}
  
</style>

<body style="background-color:#f5f0ec;background-size: inherit;" class="gray-bg">

  <?php
  include('header.php');
  ?>
  <form action="add lecture.php" method="post" enctype="multipart/form-data">
    <div class="container-fluid justify-content-center w-75 mt-2 p-4" style="border-color: #fff;border-style: solid;border-radius: 35px;background:#fff;margin-bottom: 5em;padding-bottom: 5em;">
      <div class="row justify-content-center mt-2">
        <div class="col-6" style="text-align: center;">
          <h4 style="color: #8e7f6f;font-weight: bold;"> add lecture </h4>
        </div>
      </div>


      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> course </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <select name="course" class="p-2 w-100" style="text-align: center;">
            <?php
            foreach ($query1 as $row1) {
            ?>
              <option value="<?= $row1['id'] ?>" style="text-align: center;">
                <?php echo $row1['title']; ?>
              </option>
            <?php } ?>

          </select>
        </div>
      </div>


      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> lecture name </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <input name="title" class="p-2 w-100" type="text"></input>
        </div>
      </div>

      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> description </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <input name="description" class="p-2 w-100">

          </input>
        </div>
      </div>



      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> type </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <select name="type" class="p-2 w-100" style="text-align: center;">
            <option style="text-align: center;">place</option>
            <option style="text-align: center;">link</option>
          </select>
        </div>
      </div>


      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> place/link </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <input name="place" class="p-2 w-100" type="text"></input>
        </div>
      </div>


      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> date </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <input name="date" class="p-2 w-100" type="date"></input>
        </div>
      </div>


      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> time </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <input name="time" class="p-2 w-100" type="time"></input>
        </div>
      </div>

      <div class="row justify-content-center mt-2">
        <div class="col-6" style="text-align: center;">
          <button style="background-color: #8e7f6f;border-color: #8e7f6f;" name="save_btn" type="submit" class="btn btn-success w-75"> create</button>
        </div>
      </div>
    </div>
  </form>

  </div>
  <?php
include("footer.php");
?>

</body>

</html>