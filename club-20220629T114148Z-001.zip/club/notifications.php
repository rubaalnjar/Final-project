<?php
include("conn.php");
$id = $_SESSION['id'];
$date = date('Y-m-d');
$sql1 = "SELECT * FROM course WHERE date like '$date'";
$query1 = mysqli_query($db, $sql1);


?>
<!DOCTYPE html>
<html lang="en">

<head>


    <title>presentation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .p-5 {
            padding: 2.8rem !important;
        }

        .grid-container {
            display: grid;
            grid-template-columns: auto auto auto auto auto;
            background-color: rgb(41, 85, 24);
            padding: 0px;
        }

        .grid-item {
            background-color: rgb(41, 85, 24);
            padding: 2px;
            font-size: 20px;
            text-align: center;
            color: #fff;
        }

        .hero-image {
            background-image: url("o.jpg");
            background-color: #cccccc;
            height: 200px;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            position: relative;
        }

        .hero-text {
            text-align: center;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
        }

        .sub-header {
            background-color: rgb(219, 219, 219);
        }

        .gray-bg {
            background-color: rgb(219, 219, 219);
        }

        .brown-bg {
            background-color: rgba(173, 113, 33, 0.425);
        }

        h5 {
            color: rgb(41, 85, 24);
            font-weight: bold;
        }

        .background {
            background-image: url("../images/3.jpeg");
            background-size: cover;
        }

        hr {

            border-top: 1px solid black;

        }
    </style>


</head>


<body dir="ltr" class="background" style="background-color:#f5f0ec;background-size: inherit;  background-repeat: no-repeat;">
    <?php
    include('header.php');
    ?>
    <br />

    <div class="row justify-content-center mt-1" style="margin: auto;padding-bottom:7em">
        <div class="col-12">
            <table style="background: #d4cdc3;width: 100%;text-align: center;direction: ltr;" class="table">
                <tr>
                    <th>
                        course name
                    </th>

                    <th>
                        club
                    </th>

                    <th>
                        notification
                    </th>



                </tr>
                <?php
                foreach ($query1 as $row1) {
                    $club_id = $row1['club_id'];
                    $sql2 = "SELECT * FROM club WHERE id=$club_id";
                    $query2 = mysqli_query($db, $sql2);
                    foreach ($query2 as $row2) {
                        $club_name = $row2['name'];
                    }
                ?>
                    <tr>
                        <td><?php echo $row1['title'] ?></td>
                        <td><?php echo $club_name; ?></td>
                        <td> this course is added today to our site </td>
                    </tr>

                <?php
                }
                ?>
            </table>
        </div>
    </div>

    <?php
    include("footer.php");
    ?>

</body>

</html>