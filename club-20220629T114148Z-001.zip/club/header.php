<?php

if (isset($_POST['logout_btn'])) {
  include('logout.php');
}

if (isset($_SESSION['id'])) {
  if ($_SESSION['type'] == 'admin') {
    $hide_student = 'none';
    $hide_admin = '';
    $hide_professor = 'none';
    $hide_student_adding = 'none';
  }

  if ($_SESSION['type'] == 'student') {
    $hide_professor = 'none';
    $hide_admin = 'none';
    $hide_student = '';
    $student_header_id = $_SESSION['id'];
    $sqlstudent = "SELECT * FROM student WHERE univ_id=$student_header_id";
    $querystudent = mysqli_query($db, $sqlstudent);
    foreach ($querystudent as $rowstudent) {
      $accept_training_header = $rowstudent['accept_training'];
    }
    if ($accept_training_header == 'Yes') {
      $hide_student_adding = '';
    } else {
      $hide_student_adding = 'none';
    }
  }


  if ($_SESSION['type'] == 'professor') {
    $hide_admin = 'none';
    $hide_professor = '';
    $hide_student = 'none';
    $hide_student_adding = 'none';
  }
  $hide_logout = '';
  $hide_login = 'none';
} else {
  $hide_admin = 'none';
  $hide_professor = 'none';
  $hide_student = 'none';
  $hide_student_adding = 'none';
  $hide_logout = 'none';
  $hide_login = '';
}
?>

<head>
  <style>
    th {
      text-transform: capitalize;
    }

    .grid-container {
      display: grid;
      grid-template-columns: auto auto auto auto auto;
      background-color: rgb(41, 85, 24);
      padding: 0px;
    }

    .grid-item {
      background-color: rgb(41, 85, 24);
      padding: 1px;
      font-size: 20px;
      text-align: center;
      color: #fff;
    }

    .row {
      margin-left: 0px !important;
      margin-right: 0px !important;
    }

    .navbar {
      width: 100%;
      background-color: #8e7f6f;
      overflow: hidden;
    }

    .navbar a {
      float: right;
      padding: 10px;
      color: white;
      text-decoration: none !important;
      font-size: 14px;
    }

    tr a {
      background-color: #8e7f6f !important;
      border-color: #8e7f6f !important;
      color: #fff !important;
    }

    .dropdown-menu {
      background-color: #8e7f6f !important;
    }
  </style>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" type="text/css" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<form action="header.php" method="post">
  <div class="navbar">

    <div style="width: 200px" class="row">
      <div class="col-12">
        <button style="background-color: #8e7f6f;border-color: #ffffff;display: <?= $hide_logout; ?>" name="logout_btn" class="btn btn-primary w-75 p-1">logout</button>
        <a style="background-color: #8e7f6f;border-color: #ffffff;display: <?= $hide_login; ?>" href="login.php" class="btn btn-primary w-75 p-1">login</a>
      </div>
    </div>

    <div class="dropdown" style="position: relative;margin-bottom: 4em;margin-left: 3em;background: #8e7f6f !important;display: <?php echo $hide_admin; ?>;">
      <button type="button" class="btn  dropdown-toggle" style="background: #8e7f6f !important;border:white;color: #fff;" data-toggle="dropdown">
        course management
      </button>
      <div class="dropdown-menu" style="text-align: center;">
        <a style="display: <?php echo $hide_admin; ?>;" href="add course.php"><i class="fa fa-fw fa-laptop"></i>add course</a>
        <br>
        <a style="display: <?php echo $hide_admin; ?>;" href="add lecture.php"><i class="fa fa-fw fa-file"></i>add lecture</a>
        <br>
        <a style="display: <?php echo $hide_admin; ?>;" href="courses_admin.php" style="margin-top: 0em;"><i class="fa fa-fw fa-book"></i>courses</a>
      </div>
    </div>

    <div class="dropdown" style="position: relative;margin-bottom: 4em;margin-left: 1em;background: #8e7f6f !important;display: <?php echo $hide_admin; ?>;">
      <button type="button" class="btn  dropdown-toggle" style="background: #8e7f6f !important;border:white;color: #fff;" data-toggle="dropdown">
        students
      </button>
      <div class="dropdown-menu" style="text-align: center;">
        <a style="display: <?php echo $hide_admin; ?>;" href="students.php" style="margin-top: 0em;"><i class="fa fa-fw fa-users"></i> new requests</a>
        <br>
        <a style="display: <?php echo $hide_admin; ?>;" href="accepted.php"><i class="fa fa-fw fa-users"></i>accepted</a>
        <br>
        <a style="display: <?php echo $hide_admin; ?>;" href="rejected.php"><i class="fa fa-fw fa-users"></i>rejected</a>
      </div>
    </div>


    <div class="dropdown" style="position: relative;margin-bottom: 4em;margin-left:15em;background: #8e7f6f !important;display: <?php echo $hide_student; ?>;">
      <button type="button" class="btn  dropdown-toggle" style="background: #8e7f6f !important;border:white;color: #fff;" data-toggle="dropdown">
        course management
      </button>
      <div class="dropdown-menu" style="text-align: center;">

        <a style="display: <?php echo $hide_student; ?>;" href="courses_student.php" style="margin-top: 0em;"><i class="fa fa-fw fa-laptop"></i>courses</a>
        <a style="display: <?php echo $hide_student_adding; ?>;" href="add_student_course.php" style="margin-top: 0em;"><i class="fa fa-fw fa-laptop"></i>add course</a>
        <a style="display: <?php echo $hide_student_adding; ?>;" href="add_student_lecture.php" style="margin-top: 0em;"><i class="fa fa-fw fa-file"></i>add lecture</a>

      </div>
    </div>

    <div class="dropdown" style="position: relative;margin-bottom: 4em;margin-left:10em;background: #8e7f6f !important;display: <?php echo $hide_professor; ?>;">
      <button type="button" class="btn  dropdown-toggle" style="background: #8e7f6f !important;border:white;color: #fff;" data-toggle="dropdown">
        course management
      </button>
      <div class="dropdown-menu" style="text-align: center;">
        <a style="display: <?php echo $hide_professor; ?>;" href="add lecture_club.php" style="margin-top: 0em;"><i class="fa fa-fw fa-file"></i>add lecture</a>
        <a style="display: <?php echo $hide_professor; ?>;" href="add course_club.php" style="margin-top: 0em;"><i class="fa fa-fw fa-laptop"></i>add course</a>
        <a style="display: <?php echo $hide_professor; ?>;" href="courses_teacher.php" style="margin-top: 0em;"><i class="fa fa-fw fa-book"></i>courses</a>
      </div>
    </div>

    <div class="row">
      <a href="home.php"><i class="fa fa-fw fa-home"></i> home </a>
      <a style="display: <?php echo $hide_admin; ?>;" href="student_admin_presentation.php" style="margin-top: 0em;"><i class="fa fa-fw fa-user"></i> attended</a>
      <a style="display: <?php echo $hide_admin; ?>;" href="professors.php" style="margin-top: 0em;"><i class="fa fa-fw fa-users"></i>professors</a>
      <a style="display: <?php echo $hide_admin; ?>;" href="clubs_admin.php"><i class="fa fa-fw fa-book"></i>clubs</a>
      <a style="display: <?php echo $hide_admin; ?>;" href="clubs_accept.php" style="margin-top: 0em;"><i class="fa fa-fw fa-book"></i>manage clubs</a>
      <a style="display: <?php echo $hide_admin; ?>;" href="lectures_admin.php" style="margin-top: 0em;"><i class="fa fa-fw fa-book"></i>lectures</a>
      <a style="display: <?php echo $hide_professor; ?>;" href="teacher_presentation.php" style="margin-top: 0em;"><i class="fa fa-fw fa-users"></i>attended</a>
      <a style="display: <?php echo $hide_professor; ?>;" href="add club.php" style="margin-top: 0em;"><i class="fa fa-fw fa-book"></i>add club</a>
      <a style="display: <?php echo $hide_professor; ?>;" href="lectures_teacher.php" style="margin-top: 0em;"><i class="fa fa-fw fa-book"></i>lectures</a>
      <a style="display: <?php echo $hide_professor; ?>;" href="clubs_teacher.php" style="margin-top: 0em;"><i class="fa fa-fw fa-book"></i>clubs</a>
      <a style="display: <?php echo $hide_professor; ?>;" href="courses_reg.php" style="margin-top: 0em;"><i class="fa fa-fw fa-pencil"></i>course accept</a>
      <a style="display: <?php echo $hide_professor; ?>;" href="clubs_reg.php" style="margin-top: 0em;"><i class="fa fa-fw fa-pencil"></i>club reg</a>
      <a style="display: <?php echo $hide_student; ?>;" href="clubs_student.php" style="margin-top: 0em;"><i class="fa fa-fw fa-book"></i>clubs</a>
      <a style="display: <?php echo $hide_student; ?>;" href="my_clubs_student.php" style="margin-top: 0em;"><i class="fa fa-fw fa-book"></i>my clubs</a>
      <a style="display: <?php echo $hide_student; ?>;" href="student_presentation.php" style="margin-top: 0em;"><i class="fa fa-fw fa-user"></i>attended</a>
      <a style="display: <?php echo $hide_student; ?>;" href="chatbot.php" style="margin-top: 0em;"><i class="fa fa-fw fa-desktop"></i>support</a>
      <a style="display: <?php echo $hide_student; ?>;" href="notifications.php" style="margin-top: 0em;"><i class="fa fa-fw fa-bell"></i>notifications</a>
 
      <img src="images/logo.png" style="height: 115px;width:115px;">
    </div>
  </div>
  <div>
<img src="images/h.png" style="height: 150px;width:100%;">
</div>

</form>