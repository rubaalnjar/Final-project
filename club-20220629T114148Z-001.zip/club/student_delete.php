<?php
// session_start();
include("conn.php");
$id = $_GET['id'];
$sql = "DELETE FROM student where univ_id=$id;";
$query = mysqli_query($db, $sql);
header("location:students.php");
?>
