<?php
include("conn.php");
$sql = "SELECT * FROM course";
$query = mysqli_query($db, $sql);

?>
<!DOCTYPE html>
<html lang="en">

<head>


    <title>courses</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .p-5 {
            padding: 2.8rem !important;
        }

        .grid-container {
            display: grid;
            grid-template-columns: auto auto auto auto auto;
            background-color: rgb(41, 85, 24);
            padding: 0px;
        }

        .grid-item {
            background-color: rgb(41, 85, 24);
            padding: 2px;
            font-size: 20px;
            text-align: center;
            color: #fff;
        }

        .hero-image {
            background-image: url("o.jpg");
            background-color: #cccccc;
            height: 200px;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            position: relative;
        }

        .hero-text {
            text-align: center;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
        }

        .sub-header {
            background-color: rgb(219, 219, 219);
        }

        .gray-bg {
            background-color: rgb(219, 219, 219);
        }

        .brown-bg {
            background-color: rgba(173, 113, 33, 0.425);
        }

        h5 {
            color: rgb(41, 85, 24);
            font-weight: bold;
        }

        .background {
            background-image: url("../images/3.jpeg");
            background-size: cover;
        }

        hr {

            border-top: 1px solid black;

        }
    </style>


</head>


<body dir="ltr" class="background" style="background-color:#f5f0ec;background-size: inherit;  background-repeat: no-repeat;">
    <?php
    include('header.php');
    ?>
    <br />

    <div class="row justify-content-center" style="padding-bottom:5em">
        <div class="col-12"   >
            <table style="background: #d4cdc3;width: 100%;text-align: center;direction: ltr;" class="table">
                <tr>
                    <th>
                        course name
                    </th>

                    <th>
                        description
                    </th>

                    <th>
                        start date
                    </th>

                    <th>
                        end date
                    </th>
                    <th>
                        club
                    </th>
                    <th>
                        teacher
                    </th>
                    <th>
                        delete
                    </th>

                </tr>
                <?php
                foreach ($query as $row) {
                    $student_id=$row['student_id'];
                    $club_id = $row['club_id'];
                
                if ($student_id == NULL) {
                    $sql2 = "SELECT * FROM club WHERE id=$club_id";
                    $query2 = mysqli_query($db, $sql2);
                    foreach ($query2 as $row2) {
                        $professor = $row2['professor_id'];
                    }
                    $sql3 = "SELECT * FROM professor WHERE emp_id=$professor";
                    $query3 = mysqli_query($db, $sql3);
                    foreach ($query3 as $row3) {
                        $pname = $row3['fname']." ".$row3['lname'];
                    }
                }
                else{
                    $sql4 = "SELECT * FROM student WHERE univ_id=$student_id";
                    $query4 = mysqli_query($db, $sql4);
                    foreach ($query4 as $row4) {
                        $pname = $row4['fname']." ".$row4['lname'];
                    }
                }
                ?>
                    <tr>
                        <?php
                        $club_id = $row['club_id'];
                        if ($club_id != NULL) {
                            $sql1 = "SELECT * FROM club where id = $club_id";
                            $query1 = mysqli_query($db, $sql1);
                            if (mysqli_num_rows($query1) != 0) {
                                foreach ($query1 as $row1) {
                                    $club_name = $row1['name'];
                                }
                            } else {
                                $club_name = " ";
                            }
                        } else {
                            $club_name = " ";
                        }
                        ?>

                        <td><?php echo $row['title']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td><?php echo $row['s_date']; ?></td>
                        <td><?php echo $row['e_date']; ?></td>
                        <td><?php echo $club_name; ?></td>
                        <td><?php echo $pname; ?></td>

                        <td>
                            <a class="btn btn-danger" href="./course_delete.php?id=<?= $row['id']; ?>">delete</a>
                        </td>
                    </tr>
                    
                <?php
                }
                ?>
            </table>
        </div>
    </div>

    <?php
include("footer.php");
?>

</body>

</html>