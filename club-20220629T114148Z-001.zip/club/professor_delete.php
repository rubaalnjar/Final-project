<?php
session_start();
$id = $_GET['id'];
echo $id;
include("conn.php");
$sql = "DELETE FROM professor where emp_id='$id';";
$query = mysqli_query($db, $sql);
header("location:professors.php");
?>
