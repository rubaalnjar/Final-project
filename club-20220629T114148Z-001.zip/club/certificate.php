<?php
include("conn.php");
$id = $_SESSION['id'];
$club_id = $_GET['club_id'];
$course = $_GET['course'];
$sql1 = "SELECT * FROM `student` WHERE univ_id=$id";
$query1 = mysqli_query($db, $sql1);
foreach ($query1 as $r1) {
  $name = $r1['fname'] . " " . $r1['lname'];
}

$sql2 = "SELECT * FROM `club` WHERE id=$club_id";
$query2 = mysqli_query($db, $sql2);
foreach ($query2 as $r2) {
  $professor_id = $r2['professor_id'];
}

$sql3 = "SELECT * FROM `professor` WHERE emp_id=$professor_id";
$query3 = mysqli_query($db, $sql3);
foreach ($query3 as $r3) {
  $professor_fname = $r3['fname'];
  $professor_lname = $r3['lname'];
}

?>


<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/dom-to-image/2.6.0/dom-to-image.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<style>
  .row {
    margin-left: 0em;
    margin-right: 0em;
  }
</style>

<body style="background-color:#f5f0ec;background-size: inherit;" class="gray-bg">

  <?php
  include('header.php');
  ?>
  <div class="row justify-content-center mb-1 mt-1">
    <div class="col-3">
      <button id="demo" style="font-size: 20px;font-weight: bold;background-color:#8e7f6f !important;" class="btn btn-success w-100 p-2" onclick="downloadtable()"> download</button>
    </div>
  </div>
<div class="container-fluid justify-content-center w-75 mt-1 mb-5" style="margin-bottom:10em !important;border-color: #fff;border-style: solid;border-radius: 25px;background-color: #8e7f6f;background-image: url('images/b.png');background-size: cover;background-repeat: no-repeat;" id="tablecontainer">
    <div class="row justify-content-center mt-2">
      <div class="col-8" style="text-align: center;">
        <h1 style="color:#fff;font-weight: bold;font-family: 'Courier New', Courier, monospace;"> Student Clubs
        </h1>
      </div>
    </div>

    <div class="row justify-content-center mt-1 p-2">
      <div class="col-12" style="text-align: center;">
        <h1 style="text-align: center;color: #000;font-weight: bold;">
        </h1>
        <br>
        <br>
        <br>
        <br>
        <br>

        <h1 style="text-align: center;color: #000;font-weight: bold;">
          <?= $name; ?>
        </h1>
        <br>

        <h1 style="text-align: center;color: #000;font-weight: bold;">
          has attended a course of
        </h1>
        <br>
        <h1 style="text-align: center;color: #000;font-weight: bold;">
          <?= $course; ?>
        </h1>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>

        <h2 style="text-align: left;color: #000;margin-top: 1em;">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?= $professor_fname; ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?= $professor_lname; ?>
        </h2>
      </div>
    </div>

   

  </div>


  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>



</body>
<script>
  function downloadtable() {

    var node = document.getElementById('tablecontainer');

    domtoimage.toPng(node)
      .then(function(dataUrl) {
        var img = new Image();
        img.src = dataUrl;
        downloadURI(dataUrl, "records.png")
      })
      .catch(function(error) {
        console.error('oops, something went wrong!', error);
      });

  }



  function downloadURI(uri, name) {
    var link = document.createElement("a");
    link.download = name;
    link.href = uri;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    delete link;
  }
</script>
<?php
include("footer.php");
?>
</html>