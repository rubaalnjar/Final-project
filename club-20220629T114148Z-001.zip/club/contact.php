<?php
include("conn.php");
?>


<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<style>
  .row {
    margin-left: 0em;
    margin-right: 0em;
  }
</style>

<body style="background:#d4cdc3;background-size: inherit;" class="gray-bg">

  <?php
  include('header.php');
  ?>
  <form action="home.php" method="post">
    <div class="container-fluid justify-content-center w-75 mt-1 mb-5 p-4" style="border-color: #fff;border-style: solid;border-radius: 35px;background-color: #8e7f6f;margin-bottom: 10em !important;">
      <div class="row justify-content-center mt-5">
        <div class="col-8" style="text-align: center;">
          <h3 style="color:#fff;font-weight: bold;"> 
          Support Page
          <br>
                 <a  class="btn btn-outline-light btn-floating m-1" href="./contact.php" role="button"
        ><i style="font-size: xxx-large;" class="fab fa-whatsapp"></i
      ></a>
          </h3>
        </div>
      </div>

      <div class="row justify-content-center mt-1 mb-5">
        <div class="col-12" style="text-align: center;">
          <h3 style="text-align: center;color: #fff;text-transform:lowercase;" >
you can call us From sunday to thursday From 9:00 AM to 4:00 PM <br>
<div style="text-align: center;">(126952000)</div>
<br>
or you can use chatbot if you are a member.
        </h3>
        </div>

      </div>



    </div>
  </form>

  </div>
  <?php
include("footer.php");
?>

</body>

</html>