<?php
session_start();

$club_id = $_GET['id'];
$status = $_GET['status'];
include("conn.php");
if($status==1 || $status==2){
if($status==1){
    $status_="accept";
}    
else
{
    $status_="reject";
}
$sql = "UPDATE club SET status='$status_' where id=$club_id"; 
$query = mysqli_query($db, $sql);    
}

if($status==3){
    $sql = "DELETE FROM  club  where id=$club_id"; 
    $query = mysqli_query($db, $sql);    
    }

header("location:clubs_accept.php");
?>