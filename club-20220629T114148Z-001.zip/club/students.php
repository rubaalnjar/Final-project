<?php
include("conn.php");
$sql = "SELECT * FROM student WHERE accept_training IS Null";
$query = mysqli_query($db, $sql);

?>
<!DOCTYPE html>
<html lang="en">

<head>


    <title>Students</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .p-5 {
            padding: 2.8rem !important;
        }

        .grid-container {
            display: grid;
            grid-template-columns: auto auto auto auto auto;
            background-color: rgb(41, 85, 24);
            padding: 0px;
        }

        .grid-item {
            background-color: rgb(41, 85, 24);
            padding: 2px;
            font-size: 20px;
            text-align: center;
            color: #fff;
        }

        .hero-image {
            background-image: url("o.jpg");
            background-color: #cccccc;
            height: 200px;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            position: relative;
        }

        .hero-text {
            text-align: center;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
        }

        .sub-header {
            background-color: rgb(219, 219, 219);
        }

        .gray-bg {
            background-color: rgb(219, 219, 219);
        }

        .brown-bg {
            background-color: rgba(173, 113, 33, 0.425);
        }

        h5 {
            color: rgb(41, 85, 24);
            font-weight: bold;
        }

     

        hr {

            border-top: 1px solid black;

        }
    </style>


</head>


<body dir="ltr" class="background" style="background-color:#f5f0ec;background-size: inherit;  background-repeat: no-repeat;">
    <?php
    include('header.php');
    ?>
    <br />

    <div class="row justify-content-center mt-2 mb-5" style="padding-bottom:5em">
        <div class="col-12">
            <table style="background: #d4cdc3;width: 100%;text-align: center;direction: ltr;" class="table">
                <tr>
                    <th>
                        first name
                    </th>
                    <th>
                        last name
                    </th>

                    <th>
                        email
                    </th>

                    <th>
                        phone
                    </th>


                    <th>
                    specialization </th>

                    <th>
                        univ_id
                    </th>
                    <th>
                        trainer/learner
                    </th>
                    <th>
                        attendence
                    </th>
                    <th>
                        accepted
                    </th>
                    <th>
                        accept
                    </th>
                    <th>
                        reject
                    </th>


                </tr>
                <?php
                foreach ($query as $row) {
                    $id=$row['univ_id'];
                    $sql1 = "SELECT *,COUNT(*) AS cp FROM present WHERE student_id=$id AND status like 'present'";
                    $query1 = mysqli_query($db, $sql1);
                    $count1=mysqli_num_rows($query1);
                    $sql2 = "SELECT *,COUNT(*) AS cp FROM present WHERE student_id=$id ";
                    $query2 = mysqli_query($db, $sql2);
                    $count2=mysqli_num_rows($query2);
                foreach($query2 as $row2){
                    $num2=$row2['cp'];
                }
                foreach($query1 as $row1){
                    $num1=$row1['cp'];
                } 
                if($num2!=0)
                {
                    $num=$num1/$num2 * 100;
                }
                else{
                    $num=0;
                }
                ?>
                    <tr>
                        <td><?= $row['fname']; ?></td>
                        <td><?= $row['lname']; ?></td>
                        <td><?= $row['email']; ?></td>
                        <td><?= $row['phone']; ?></td>
                        <td><?= $row['specialization']; ?></td>
                        <td><?= $row['univ_id']; ?></td>
                        <td><?= $row['trainer']; ?></td>
                        <td><?=$num;?>%</td>
                        <td><?= $row['accept_training']; ?></td>
                        <td>
                            <a class="btn btn-danger" href="./student_accept.php?id=<?= $row['univ_id']; ?>&accept=Yes">accept</a>
                        </td>

                        <td>
                            <a class="btn btn-danger" href="./student_accept.php?id=<?= $row['univ_id']; ?>&accept=No">reject</a>
                        </td>

                    </tr>
                <?php
                }
                ?>
            </table>
        </div>
    </div>

    <?php
include("footer.php");
?>

</body>

</html>