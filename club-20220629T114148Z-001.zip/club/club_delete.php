<?php
session_start();
$id = $_GET['id'];
include("conn.php");
$sql = "DELETE FROM club where id=$id;";
$query = mysqli_query($db, $sql);
if($_SESSION['type']=='admin'){
header("location:clubs_admin.php");
}
else{
header("location:clubs_teacher.php");
}
?>
