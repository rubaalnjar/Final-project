<?php
include("conn.php");
$sql1 = "SELECT *,COUNT(*) AS cp FROM present WHERE  status like 'present' 
GROUP BY student_id ORDER BY id DESC";
$query1 = mysqli_query($db, $sql1);

?>
<!DOCTYPE html>
<html lang="en">

<head>


  <title>presentation</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <style>
    .p-5 {
      padding: 2.8rem !important;
    }

    .grid-container {
      display: grid;
      grid-template-columns: auto auto auto auto auto;
      background-color: rgb(41, 85, 24);
      padding: 0px;
    }

    .grid-item {
      background-color: rgb(41, 85, 24);
      padding: 2px;
      font-size: 20px;
      text-align: center;
      color: #fff;
    }

    .hero-image {
      background-image: url("o.jpg");
      background-color: #cccccc;
      height: 200px;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
      position: relative;
    }

    .hero-text {
      text-align: center;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      color: white;
    }

    .sub-header {
      background-color: rgb(219, 219, 219);
    }

    .gray-bg {
      background-color: rgb(219, 219, 219);
    }

    .brown-bg {
      background-color: rgba(173, 113, 33, 0.425);
    }

    h5 {
      color: rgb(41, 85, 24);
      font-weight: bold;
    }

    .background {
      background-image: url("../images/3.jpeg");
      background-size: cover;
    }

    hr {

      border-top: 1px solid black;

    }
  </style>


</head>


<body dir="ltr" class="background" style="background-color:#f5f0ec;background-size: inherit;  background-repeat: no-repeat;">
  <?php
  include('header.php');
  ?>
  <br />

  <div class="row justify-content-center mt-1" style="margin: auto;overflow-y: scroll;padding-bottom:5em">
    <div class="col-12">
      <table style="background: #d4cdc3;width: 100%;text-align: center;direction: ltr;" class="table">
        <tr>
          <th>
            student
          </th>



          <th>
            attend
          </th>

          <th>
            absent
          </th>
          <th>
            percent
          </th>
        </tr>
        <?php
        foreach ($query1 as $row1) {
          $s_id = $row1['student_id'];
          $sql2 = "SELECT COUNT(*) AS ca FROM present WHERE (student_id=$s_id AND status NOT like 'present')";
          $query2 = mysqli_query($db, $sql2);
          foreach ($query2 as $row2) {
            $absent = $row2['ca'];
          }
          $sql3 = "SELECT * FROM student WHERE univ_id=$s_id";
          $query3 = mysqli_query($db, $sql3);
          foreach ($query3 as $row3) {
            $name = $row3['fname'] . " " . $row3['lname'];
          }
          $sql4 = "SELECT *,COUNT(*) AS cp FROM present  GROUP BY student_id ORDER BY id DESC";
          $query4 = mysqli_query($db, $sql4);
          foreach ($query4 as $row4) {
            $total=$row4['cp'];
          }
          $percent=$row1['cp']*100/$total;
        ?>
          <tr>

            <td><?php echo $name;?></td>
            <td><?php echo $row1['cp'];?></td>
            <td><?php echo $absent;?></td>
            <td><?php echo $percent;?>%</td>

          </tr>
        <?php
        }
        ?>
      </table>
    </div>
  </div>

  <?php
  include("footer.php");
  ?>

</body>

</html>