<?php
include("conn.php");
$id = $_GET['id'];
$s_id=$_SESSION['id'];
$sql = "INSERT INTO student_club(student_id,club_id) VALUES($s_id,$id)";
$query = mysqli_query($db, $sql);
header("location:clubs_student.php");
?>
