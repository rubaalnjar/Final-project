<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<footer class="bg-dark text-center text-white" style="position: fixed;bottom: 0;left: 0;width: 100%;background-color: #d2c6b1 !important;">
  <!-- Grid container -->
  <div class="container p-1">
    <!-- Section: Social media -->
    <section class="mb-1">
 
      <!-- Twitter -->
      <a target="_blank" class="btn btn-outline-light btn-floating m-1" href="https://twitter.com/kauweb?s=11" role="button"
        ><i class="fab fa-twitter"></i
      ></a>

      <!-- Google -->
      <a target="_blank" class="btn btn-outline-light btn-floating m-1" href="mailto:club@gmail.com" role="button"
        ><i class="fa fa-envelope" aria-hidden="true"></i></a>

     </a>


            <!-- Whatsapp -->
            <a  class="btn btn-outline-light btn-floating m-1" href="./contact.php" role="button"
        ><i class="fab fa-whatsapp"></i
      ></a>

    </section>
    <!-- Section: Social media -->


    <!-- Section: Links -->
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-2" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2022 Copyright:
    <a class="text-white" href="http://localhost/club/home.php">club.com</a>
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
    th {
      text-transform: capitalize;
    }

    .grid-container {
      display: grid;
      grid-template-columns: auto auto auto auto auto;
      background-color: rgb(41, 85, 24);
      padding: 0px;
    }

    .grid-item {
      background-color: rgb(41, 85, 24);
      padding: 1px;
      font-size: 20px;
      text-align: center;
      color: #fff;
    }

    .row {
      margin-left: 0px !important;
      margin-right: 0px !important;
    }

    .navbar {
      width: 100%;
      background-color: #8e7f6f;
      overflow: auto;
    }

    .navbar a {
      float: right;
      padding: 10px;
      color: white;
      text-decoration: none !important;
      font-size: 14px;
    }
    tr a {
      background-color: #8e7f6f !important;
      border-color: #8e7f6f !important;
      color: #fff !important;
    }
  </style>
