<?php
include("conn.php");
$id = $_SESSION['id'];
$sql1 = "SELECT * FROM club where (id IN (SELECT club_id from student_club WHERE student_id=$id AND `status` like 'accept')) AND `status` like 'accept'";
$query1 = mysqli_query($db, $sql1);
if (isset($_POST['save_btn'])) {
  $title = $_POST['title'];
  $description = $_POST['description'];
  $place = $_POST['place'];
  $capacity = $_POST['capacity'];
  $type = $_POST['type'];
  $number=$_POST['number'];
  $start = $_POST['start_date'];
  $end = $_POST['end_date'];
  $club=$_POST['club'];
  $sql = "INSERT INTO course(title,description,s_date,e_date,place,capacity,number,type,student_id,club_id)
VALUES('$title','$description','$start','$end','$place',$capacity,$number,'$type',$id,$club)";
  $query = mysqli_query($db, $sql);
}





?>


<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<title>add course</title>
<style>
  .row {
    margin-left: 0em;
    margin-right: 0em;
  }
  h4,h5{
  text-transform: capitalize;
  }

</style>

<body style="background-color:#f5f0ec;background-size: inherit;" class="gray-bg">

  <?php
  include('header.php');
  ?>
  <form action="add_student_course.php" method="post" enctype="multipart/form-data">
    <div class="container-fluid justify-content-center w-75 mt-2 p-4" style="border-color: #fff;border-style: solid;border-radius: 35px;background:#fff;margin-bottom: 5em;padding-bottom: 5em;">
      <div class="row justify-content-center mt-2">
        <div class="col-6" style="text-align: center;">
          <h4 style="color: #8e7f6f;font-weight: bold;"> add course </h4>
        </div>
      </div>


      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> course name </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <input name="title" class="p-2 w-100" type="text"></input>
        </div>
      </div>

      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> description </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <textarea name="description" class="p-2 w-100">

          </textarea>
        </div>
      </div>


      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> place/link </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <input name="place" class="p-2 w-100" type="text"></input>
        </div>
      </div>



      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> capacity </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <input name="capacity" class="p-2 w-100" type="number"></input>
        </div>
      </div>

      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> lecture number </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <input name="number" class="p-2 w-100" type="number"></input>
        </div>
      </div>

      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> start date </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <input name="start_date" class="p-2 w-100" type="date"></input>
        </div>
      </div>


      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> end date </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <input name="end_date" class="p-2 w-100" type="date"></input>
        </div>
      </div>



      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> type </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <select name="type" class="p-2 w-100" style="text-align: center;">
            <option style="text-align: center;">lecture</option>
            <option style="text-align: center;">workshop</option>
          </select>
        </div>
      </div>

      <div class="row justify-content-center mt-2">
        <div class="col-6 mt-1 " style="text-align: center;">
          <h5 style="background-color: #8e7f6f;color: #fff;padding: 5px;"> club </h5>
        </div>
        <div class="col-6" style="text-align: center;">
          <select name="club" class="p-2 w-100" style="text-align: center;">
            <?php 
            foreach($query1 as $row1){
             ?>
              <option value="<?=$row1['id']?>" style="text-align: center;">
           <?php echo $row1['name']; ?>
               </option>
              <?php } ?>

          </select>
        </div>
      </div>



      <div class="row justify-content-center mt-2 mb-2">
        <div class="col-6" style="text-align: center;">
          <button style="background-color: #8e7f6f;border-color: #8e7f6f;" name="save_btn" type="submit" class="btn btn-success w-75"> create</button>
        </div>
      </div>
    </div>
  </form>

  </div>
  <?php
include("footer.php");
?>

</body>

</html>