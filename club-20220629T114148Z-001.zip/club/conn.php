<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
$server="localhost";
$username="root";
$password="";
$dbname="club";
$db=mysqli_connect($server,$username,$password,$dbname);
?>

